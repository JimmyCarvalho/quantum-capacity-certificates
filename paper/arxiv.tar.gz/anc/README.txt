Ancillary files for "Emergent Gaussian channels for Pauli noise: certified quantum-capacity thresholds
and positive capacity of the additive Gaussian noise channel beyond 1/sqrt(e)" (J. K. E. Carvalho).

pauli-emergence/        finite-M and Gaussian-limit code, certifiers (certify_finite.py, certify_big.py,
                        certify_limit.py) and the input states of every certificate (runs/*.npy)
depolarizing-threshold/ Gaussian-channel tools, the Arb Fock-space certifier (certify.py), the 128-bit
                        evaluator/optimizer (hp_ic.py, hp_par.py, hp_cont.py) and the depolarizing
                        Gaussian-limit states (runs/*.npy)
CERTIFICATES.md         every certificate: exact parameters, state file, SHA-256, command, interval
verify_certificates.sh  re-runs the certificates and checks the hashes ("quick" or "full")

Requirements: Python 3, numpy, scipy, python-flint 0.9 (requirements.txt). Full work report, run logs and
issue tracker: https://github.com/JimmyCarvalho/quantum-capacity-certificates
